package com.example.trascau_teodor_bogdan_1101;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class SecondActivity extends AppCompatActivity {

    List<Rezervare> rezervari;
    private final String key_rezervari = "KEY_REZERVARI";
    Button secondButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_second);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Init();

        secondButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getIntent().putExtra(key_rezervari,(Serializable) rezervari);
                setResult(RESULT_OK, getIntent());
                finish();
            }
        });

    }

    void Init()
    {
        rezervari = new ArrayList<>();
        Rezervare r1 = new Rezervare(1000000001,"cash",200.00F);
        Rezervare r2 = new Rezervare(1000000002,"card",345.56F);
        Rezervare r3 = new Rezervare(1000000003,"cash",127.48F);

        rezervari.add(r1);
        rezervari.add(r2);
        rezervari.add(r3);

        secondButton = findViewById(R.id.trascau_teodor_bogdan_btnSecond);
    }
}