package com.example.trascau_teodor_bogdan_1101;

import java.io.Serializable;

public class Rezervare implements Serializable {
    long codClient;
    String modalitatePlata;
    float sumaAchitata;

    public  Rezervare()
    {
        this.codClient = 1000000000;
        this.sumaAchitata = 0.01F;
        this.modalitatePlata = "cash";
    }
    public Rezervare(long codCleint, String modalitatePlata, float sumaAchitata) {
        this.codClient = codCleint;
        this.modalitatePlata = modalitatePlata;
        this.sumaAchitata = sumaAchitata;
    }

    @Override
    public String toString() {
        return "Rezervare{" +
                "codCleint=" + codClient +
                ", modalitatePlata='" + modalitatePlata + '\'' +
                ", sumaAchitata=" + sumaAchitata +
                '}';
    }
}
