package com.example.trascau_teodor_bogdan_1101;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.List;
import java.util.stream.Collectors;

public class MainActivity extends AppCompatActivity {

    List<Rezervare> list;
    ListView lv;
    ActivityResultLauncher<Intent> launcher;
    Button addData;

    private final String key_rezervari = "KEY_REZERVARI";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        lv = findViewById(R.id.trascau_teodor_bogdan_lvMain);
        addData = findViewById(R.id.trascau_teodor_bogdan_btnMain);
        launcher = createLauncher();
        addData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),SecondActivity.class);
                launcher.launch(intent);
            }
        });

    }

    private ActivityResultCallback<ActivityResult> createCallBack()
    {
        return  new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult o) {
                if(o.getResultCode() == RESULT_OK && o.getData() != null)
                {
                     list = (List<Rezervare>) o.getData().getSerializableExtra(key_rezervari);
                    ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(), androidx.appcompat.R.layout.support_simple_spinner_dropdown_item);
                    adapter.addAll(list.stream().map(Rezervare::toString).collect(Collectors.toList()));
                    lv.setAdapter(adapter);
                }
            }
        };
    }


    private ActivityResultLauncher<Intent> createLauncher()
    {
        ActivityResultCallback<ActivityResult> callback = createCallBack();

        return registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),callback);
    }
}